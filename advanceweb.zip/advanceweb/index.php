<?php
session_start();
$connect=mysqli_connect("localhost","root","","onlineordering");

if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'item_quantity'          =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array; 
                 
           }  
           else  
           {  
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="index.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'               =>     $_POST["hidden_name"],  
                'item_price'          =>     $_POST["hidden_price"],  
                'item_quantity'          =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="cart.php"</script>';  
                }  
           }  
      }  
 }  
 ?>  


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="javascript" href="bootstrap/js/bootstrap.min.js">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/v4-shims.css">
 	<link rel="stylesheet" type="text/css" href="css/menustyle.css">
 	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
</head>
<body>
<!--NAVBAR-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">MOMMYS TUMMY</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto w-100 justify-content-end sticky-top">
      <li class="nav-item">
        <a class="nav-link active" href="index.php">Menu</a>
      </li>
      <li class="nav-item">
      	<a class="nav-link" href="cart.php">Cart</a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="#">About us</a>
      </li>
  </div>
</nav>
<!--BANNER-->
<div class="banner1">
	<img src="images/indexbanner.png">
</div>
<br>
<br>
<!--ADDING MENU-->
<h3 class="display-2" style="text-align: center;">Mommy's Tummy MENU</h3>
<div class="container pads" style="margin-top: 20px;margin-bottom: 20px;">
	<div class="row">
		<div class="col-sm-8">
			<input type="hidden">
		</div>
		<div class="col-sm-2">
			<input type="hidden">
		</div>
		<?php 
		$query="SELECT * FROM menutable ORDER BY id ASC";
		$result=mysqli_query($connect,$query);
		if(mysqli_num_rows($result) > 0)
		{
			while ($row =mysqli_fetch_array($result)) 
			{  ?>  
                <div class="col-md-4">  
                     <form method="post" action="index.php?action=add&id=<?php echo $row["id"]; ?>">  
                          <div style="margin-top:10px;border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
                          		<?php echo "<img src='images/".$row['menuimage']."' width='150' height='150'>" ?>
                          
                               <h4 class="text-info"><?php echo $row["menuname"]; ?></h4>  
                               <h4 class="text-danger">P<?php echo $row["menuprice"]; ?></h4>  
                               <input type="text" name="quantity" class="form-control" value="1"  style="width:90px;" />  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["menuname"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["menuprice"]; ?>" />  
                               <input type="submit" name="add_to_cart" style="margin-top:10px;margin-bottom:5px;" class="btn btn-success" value="Add to Cart" />  
                          </div>  
                     </form>  
                </div>  
				  <?php  
                     }  
                }  
                ?> 
		
		
		
		

</body>
</html>