<?php  

include('db_connect.php');

$stmt = $connect->prepare("SELECT menuname, menuprice,menucategory,menuimage FROM menutable WHERE menucategory='All Day Mereinda'");

$stmt ->execute();
$stmt -> bind_result($menuname,$menuprice, $menucategory,$menuimage);

 $menutable=array();

 while($stmt ->fetch()){

 	$temp =array();


 	$temp['menuname'] =$menuname;
 	$temp['menuprice'] =$menuprice;
 	$temp['menucategory'] =$menucategory;
 	$temp['menuimage'] =$menuimage;


 	array_push($menutable, $temp);
 }
 	echo json_encode($menutable);


?>


