<?php

$mysqli = new mysqli('localhost','root','','onlineordering') or die(mysqli_error($mysqli));

if (isset($_POST['register'])) 
{
	$adminuser	=	$_POST['adminuser'];
	$adminpass	=	$_POST['lastname'];
	$firstname	=	$_POST['firstname'];
	$lastname	=	$_POST['lastname'];
	
	$mysqli->query("INSERT INTO admin(adminuser,adminpass,firstname,lastname) VALUES('$adminuser','$adminpass','$firstname','$lastname')") or die(mysql_error($mysqli));

	
}

if (isset($_POST['change']))
{
	$id			=	$_POST['id'];
	$adminuser	=	$_POST['adminuser'];
	$adminpass	=	$_POST['adminpass'];
	$firstname	=	$_POST['firstname'];
	$lastname	=	$_POST['lastname'];


	$mysqli->query("UPDATE admin SET adminuser='$adminuser', adminpass='$adminpass', firstname='$firstname',lastname='$lastname' WHERE id=$id") or die($mysqli->error);
}

if (isset($_POST['updateacc']))
{
	$id			=	$_POST['updateid'];
	$adminuser	=	$_POST['adminuser'];
	$adminpass	=	$_POST['adminpass'];
	$firstname	=	$_POST['firstname'];
	$lastname	=	$_POST['lastname'];

	$mysqli->query("UPDATE admin SET adminuser='$adminuser', adminpass='$adminpass', firstname='$firstname',lastname='$lastname' WHERE id=$id") or die($mysqli->error);

}

if (isset($_POST['deleteacc']))
{
	$deleteid=$_POST['deleteid'];
	$mysqli->query("DELETE FROM admin WHERE id=$deleteid") or die($mysqli->error());

}
?>