<?php
$connect=mysqli_connect("localhost","root","","onlineordering");//object
if (!$connect) 
	{
	die("failed connect to MySQL".mysqli_connect_error());
	//die is terminate the message
	//.mysqli_connect_error() - display the specific error. 
	}
?>


